// Configure with your Supabase project URL and anon public key
const SUPABASE_URL = "https://your_project_ref.supabase.co";
const SUPABASE_KEY = "your_anon_public_key";

export { SUPABASE_URL, SUPABASE_KEY };
